"""AIPD-OS v5.1.

AIPD-OS（AI 产品工程决策操作系统）是一个面向 AI 产品工程全生命周期的决策与编排操作系统。
本包为 v5.1 的工程基础层，提供统一配置、结构化日志、CLI 入口与脚本骨架。

AIPD-OS (AI Product/Program Decision Operating System) is an orchestration OS
covering the full lifecycle of AI product engineering decisions.
This package is the v5.1 engineering foundation layer providing unified
configuration, structured logging, a CLI entry point and script skeletons.
"""

__version__ = "5.4.0"

__all__ = ["__version__"]