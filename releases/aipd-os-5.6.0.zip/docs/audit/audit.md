# AIPD-OS 版本真实性审计报告（v5.1）

- 生成时间：`2026-08-12T12:14:53`
- 仓库根目录：`/Volumes/Extra/CodeProj/AI全链路自研/AIPD-OS`

## 1. 仓库基本信息

- 默认分支：`main`
- 最新提交 SHA：`7176553105715a48951fa52d0b30403a655d47bf`
- 最新提交时间：`2026-08-12 12:14:24 +0800`
- pyproject 版本：`5.6.0`
- Git 标签：`v5.5.0`, `v5.6.0`
- `releases/` 目录存在：是

## 2. 文件树概览

- 顶层条目数：`47`
- 顶层目录文件数（一层）：

| 目录 | 文件数 |
| --- | --- |
| `.git/` | 8 |
| `.github/` | 0 |
| `.mypy_cache/` | 2 |
| `.pytest/` | 1 |
| `.pytest_cache/` | 3 |
| `.release_keys/` | 2 |
| `.ruff_cache/` | 2 |
| `.trae/` | 0 |
| `.venv/` | 1 |
| `.venv-ci/` | 1 |
| `agents/` | 1 |
| `assets/` | 0 |
| `build/` | 2 |
| `data/` | 1 |
| `dist/` | 3 |
| `docs/` | 2 |
| `evals/` | 13 |
| `evals_out/` | 0 |
| `migrations/` | 2 |
| `references/` | 36 |
| `releases/` | 4 |
| `scripts/` | 36 |
| `src/` | 0 |
| `state_service/` | 3 |
| `templates/` | 3 |
| `tests/` | 115 |

## 3. CI 状态

- 检测到 Workflow：13 个 job
- Job 列表：`unit`, `integration`, `schema-validation`, `maturity-consistency`, `cad-golden-loop`, `python-core-matrix`, `secret-scan`, `dependency-audit`, `license-scan`, `package-build`, `audit`, `skill-quality-and-coverage`, `release-ready`

## 4. Release Manifest 校验

- Manifest 版本：`5.6.0`
- 文件条目总数：`482`
- 哈希匹配：`461` / `482`
- 哈希不匹配：`21`
- 不匹配明细（前 20 条）：
  - `src/aipd_os/cli/commands.py`：hash_mismatch（期望 8edb5d539265…）
  - `src/aipd_os/cli/main.py`：hash_mismatch（期望 97c732222b8c…）
  - `src/aipd_os/cli/product_commands.py`：hash_mismatch（期望 06f1e4954098…）
  - `src/aipd_os/product_intelligence/__init__.py`：hash_mismatch（期望 04bd9ae0bbc3…）
  - `src/aipd_os/product_intelligence/gate.py`：hash_mismatch（期望 a8489ca4ff4e…）
  - `src/aipd_os/product_intelligence/models.py`：hash_mismatch（期望 92ff33a2c227…）
  - `src/aipd_os/product_intelligence/service.py`：hash_mismatch（期望 4ba95041a9d1…）
  - `src/aipd_os/product_intelligence/snapshot.py`：hash_mismatch（期望 d9cc5b4b877e…）
  - `src/aipd_os/product_truth/lineage.py`：hash_mismatch（期望 3d691d7d14fc…）
  - `src/aipd_os/product_truth/store.py`：hash_mismatch（期望 53a11a2c76f3…）
  - `src/aipd_os/runtime.py`：hash_mismatch（期望 8723777eafaa…）
  - `src/aipd_os/state/migrations.py`：hash_mismatch（期望 29153b74583e…）
  - `src/aipd_os/supervisor/idea_capabilities.py`：hash_mismatch（期望 adf26749c15d…）
  - `src/aipd_os/tool_adapters/product_adapters.py`：hash_mismatch（期望 622bcf59e662…）
  - `tests/test_idea_domain.py`：hash_mismatch（期望 fc0f987f272f…）
  - `tests/test_migration_freeze.py`：hash_mismatch（期望 5491dd14b805…）
  - `tests/test_product_definition_integrity.py`：hash_mismatch（期望 87aaef61d674…）
  - `tests/test_product_intelligence.py`：hash_mismatch（期望 49f4a99784de…）
  - `tests/test_product_intelligence_golden_e2e.py`：hash_mismatch（期望 037c37ca192f…）
  - `tests/test_product_intelligence_runtime_e2e.py`：hash_mismatch（期望 9f7ae392f122…）

## 5. 未跟踪 / 生成文件

- 共 `7` 项：
  - ` M PROVENANCE.json`
  - ` M SOURCE_MANIFEST.json`
  - ` M docs/audit/V5_9_2_RE_AUDIT_MATRIX.md`
  - `?? scripts/_v592_p004_check.py`
  - `generated .venv/lib/python3.9/site-packages/numpy/distutils/__pycache__`
  - `generated build/bundle_stage/src/aipd_os.egg-info`
  - `generated src/aipd_os.egg-info`

## 6. 遗留 CAD 冲突

- 未发现 CAD-L 级联记号或过度声称模式。

## 7. 交付产物完整性

- SBOM.md 存在：是
- 发布签名（RELEASE_SIGNING.md + scripts/sign_release.py）完备：是
- 依赖锁文件存在：是（`requirements-quality.txt`）

